/**
 * 
 */
package psd.parser;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
//import java.util.regex.Matcher;

import javax.imageio.ImageIO;

import psd.parser.layer.LayersSectionParser;
import psd.parser.layer.LayerParser;
import psdtool.TreeLayerModel;
import psd.model.Psd;
import psd.model.Layer;
import psd.parser.object.PsdDescriptor;
import psd.parser.object.PsdObject;
import psd.parser.object.PsdText;
import psd.parser.object.PsdTextData;


import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.io.File;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.transform.OutputKeys;



//import com.alternativagame.resource.utils.psd.layer.PSDLayerPixelData;
//import com.alternativagame.resource.utils.psd.layer.PSDLayerStructure;
//import com.alternativagame.resource.utils.psd.section.PSDLayerAndMask;

/**
 * 
 * 
 */
public class TestPSD {
    
    public static DocumentBuilderFactory dbFactory;
    public static DocumentBuilder dBuilder;
    public static Document doc;
    public static Element rootElement;
    public static Element layerspsd;
   public static FileOutputStream out;
   public static FileOutputStream color;
   public static FileOutputStream string;
   public static int counter=0;
    
    public static void main(String[] args) throws IOException {
  //  String text="<TextView";  
File output= new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/android/output.xml");
output.getParentFile().mkdirs();
output.createNewFile();
out=new FileOutputStream(output);

File colors= new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/android/values/colors.xml");
colors.getParentFile().mkdirs();
colors.createNewFile();
color = new FileOutputStream(colors);

File strings= new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/android/values/strings.xml");
strings.getParentFile().mkdirs();
strings.createNewFile();
string = new FileOutputStream(strings);

//out.write(x.getBytes());
	PsdFileParser parser = new PsdFileParser();
  parser.parse(new FileInputStream("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/contacts.psd"));
	LayersSectionParser layers= parser.getLayersSectionParser();
       List<LayerParser> layers1 = layers.getLayers();
     //  System.out.println(layers1);
        
        for(LayerParser layer: layers1){
           System.out.println(layer.getName()+""+ layer.getleft()+layer.gettop());
            
        }
        Psd psd = new Psd(new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/contacts.psd"));
        
        TreeLayerModel tree = new TreeLayerModel();
        
        tree.setPsd(psd);
        
    //    for(int i=0;i<tree.getChildCount(tree.getRoot());i++){
              //System.out.println((tree.getRoot()).hashCod);
        
      try{        
           dbFactory = DocumentBuilderFactory.newInstance();
           dbFactory.setNamespaceAware(true);
         dBuilder = dbFactory.newDocumentBuilder();
          doc = dBuilder.newDocument();
         
           rootElement = doc.createElement("psd");
         doc.appendChild(rootElement);
         
         layerspsd = doc.createElement("layers");
         rootElement.appendChild(layerspsd);
         
         
         String xml="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n";
         out.write(xml.getBytes());
         
         String linear="<RelativeLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n\tandroid:orientation=\"vertical\" android:layout_width=\"match_parent\"\n\tandroid:layout_height=\"match_parent\">\n";
         out.write(linear.getBytes());
         
          String colorstart="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +"<resources>\n";     
          color.write(colorstart.getBytes());
          string.write(colorstart.getBytes());
          
         
         
      }catch(Exception e){
          e.printStackTrace();
      }      
        
        struct(tree, tree.getRoot(),tree.getChildCount(tree.getRoot()),layerspsd);
        
        String endlinear="</RelativeLayout>";
        out.write(endlinear.getBytes());
        out.close();
        
        String endcolor="</resources>";
        color.write(endcolor.getBytes());
        color.close();
        
        string.write(endcolor.getBytes());
        string.close();
        
       
        try{ 
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
         Transformer transformer = transformerFactory.newTransformer();
         
        doc.setXmlStandalone(true);
transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
         transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        
         DOMSource source = new DOMSource(doc);
         StreamResult result = new StreamResult(new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/test.xml"));
         transformer.transform(source, result);
        }catch(Exception e){
            e.printStackTrace();
        }
 
}
    public static void struct(TreeLayerModel m, Object k,int c,Element e) throws IOException{
        if(c>0){
            
            for(int i=c-1;i>=0;i--){
                
        
      // if((m.getChildCount(m.getChild(k, i))>0)){
           String name =((Layer)m.getChild(k, i)).getName();
   
           String name1=name;          
        
          String reg = "[^a-zA-Z0-9]";
          
          if(Character.isDigit(name.charAt(0))){
           name1="_"+name;
           
          }
        
         name1=name1.replaceAll(reg, "_");
         
             System.out.println(name1+((Layer)m.getChild(k, i)).getX()+((Layer)m.getChild(k, i)).getY());
          
       //  createFolder();
       

       
       Element childFolder = createFolderLayer(e, name1,((Layer)m.getChild(k, i)).getX(),((Layer)m.getChild(k, i)).getY(),((Layer)m.getChild(k, i)).getWidth(),((Layer)m.getChild(k, i)).getHeight(),m.getChildCount(m.getChild(k, i)));
           
       
  
           // }
        struct(m,m.getChild(k, i),m.getChildCount(m.getChild(k, i)),childFolder);
            }
             System.out.println("endofnode");
        }
        else{
            PsdDescriptor x= ((Layer)k).getProperties();
              
               
               if(x!=null){
                  
                  Map properties1 =x.getObjects();
                   PsdTextData y= (PsdTextData)properties1.get("EngineData");
                   Map<String,Object> properties = y.getProperties();
             //   String fontName=  (String)((Map)((ArrayList)((Map)(properties.get("ResourceDict"))).get("FontSet")).get(0)).get("Name");
           //  PsdText text = (PsdText)properties1.get("Txt");
             
             String FontText= (properties1.get("Txt")).toString();
                  
                  String FontName = getFontName(properties);
                   Double FontSize = getFontSize(properties);
                   Integer FontSize1=FontSize.intValue();
                   ArrayList<Double> FontColor = getFontColor(properties);
                
                   
           createColorXml(k,FontColor);
           createStringXml(k,FontText);
           
                              float y1 = ((Layer)k).getY();
                              int y2 =(int) (y1/2.1f);
                              System.out.println(y2);
 
           createTextLayer(e,FontText,k,FontName,FontSize1,FontColor,((Layer)k).getX()/2,y2,((Layer)k).getWidth()/2,((Layer)k).getHeight()/2);
         
           

                   
                  System.out.println(properties1);
                 
               }
               else if(((Layer)k).getChannelsCount()>=4){
                     String name =((Layer)k).getName();
   
           String name1=name;          
        
          String reg = "[^a-zA-Z0-9]";
          
          if(Character.isDigit(name.charAt(0))){
           name1="_"+name;
           
          }
        
         name1=name1.replaceAll(reg, "_");
                   
                   
                   BufferedImage image = ((Layer)k).getImage();
                   File srcfolder=new File("/Users/mohsinkhan/NetBeansProjects/java-psd-library-master/src/psd/parser/android/drawable/"+name1+".png");
                   srcfolder.mkdirs();
                   ImageIO.write(image, "png", srcfolder);
           
                    float y1 = ((Layer)k).getY();
                              int y2 =(int) (y1/2.1f);
                              System.out.println(y2);
                   createImageLayer(name1,e,((Layer)k).getX()/2,y2,((Layer)k).getWidth()/2,((Layer)k).getHeight()/2);
           
           
           
                       System.out.println("image"); 
               }
            System.out.println("end");
        }
        
    
  }   
    
    
     public static String getFontName(Map<String,Object> properties){
   
               return (String)((Map)((ArrayList)((Map)(properties.get("ResourceDict"))).get("FontSet")).get(0)).get("Name");
        }
       public static Double getFontSize(Map<String,Object> properties){
    return ((Double)( (Map)( (Map)( (Map)( (ArrayList)( (Map)((Map)(properties.get("EngineDict"))).get("StyleRun") ).get("RunArray") ).get(0) ).get("StyleSheet") ).get("StyleSheetData") ).get("FontSize")  );
        }
       public static ArrayList<Double> getFontColor(Map<String,Object> properties){
            ArrayList<Double> x=(( (ArrayList)((Map)( (Map)( (Map)( (Map)( (ArrayList)( (Map)((Map)(properties.get("EngineDict"))).get("StyleRun") ).get("RunArray") ).get(0) ).get("StyleSheet") ).get("StyleSheetData") ).get("FillColor")).get("Values")) );
           if(x.isEmpty()){return x;}
           Double e = x.remove(0);
           x.add(x.size(),e);
            
            return x;
        }
       
       public static Element createFolderLayer(Element e, String name1, int x,int y,int width,int height,int childCount){
        Element childFolder = doc.createElement("layer");
        
            e.appendChild(childFolder);
          if(childCount>0){ 
           Attr type = doc.createAttribute("type");
           type.setValue("group");
           childFolder.setAttributeNode(type);
          }
           
           Attr nameoflayer= doc.createAttribute("name");
           nameoflayer.setValue(name1);
           childFolder.setAttributeNode(nameoflayer);
           
         
          /*   Attr nameoflayer1= doc.createAttributeNS("android:id", "and");
           nameoflayer1.setValue("aaaa");
           childFolder.setAttributeNode(nameoflayer1);    */
           
           Attr xoflayer= doc.createAttribute("x");
           String xoflayer1 = x+"";
           xoflayer.setValue(xoflayer1);
           childFolder.setAttributeNode(xoflayer);
           
              Attr yoflayer= doc.createAttribute("y");
           String yoflayer1 = y+"";
           yoflayer.setValue(yoflayer1);
           childFolder.setAttributeNode(yoflayer);
           
                  Attr heightoflayer= doc.createAttribute("height");
           String heightoflayer1 = height+"";
           heightoflayer.setValue(heightoflayer1);
           childFolder.setAttributeNode(heightoflayer);
           
              Attr widthoflayer= doc.createAttribute("width");
           String widthoflayer1 = width+"";
           widthoflayer.setValue(widthoflayer1);
           childFolder.setAttributeNode(widthoflayer);
           
           return childFolder;
    }

    public static void createTextLayer(Element e,String FontText,Object k, String FontName, Integer FontSize, ArrayList<Double> FontColor,int x,int y,int width,int height) {
        
        try {
                    String name =((Layer)k).getName();
   
           String name1=name; 
          
        
          String reg = "[^a-zA-Z0-9]";
          
          if(Character.isDigit(name.charAt(0))){
           name1="_"+name;
           
          }
        
         name1=name1.replaceAll(reg, "_");
          String name2=name1;
         name1+="_color";
         
            out.write(("<TextView "+"android:id= "+"\""+"@+id/"+name2+"_"+counter+"\"\n\t").getBytes());
            out.write(("android:text= "+"\""+"@string/"+name2+"_string"+"\"\n\t").getBytes());
            out.write(("android:fontFamily= "+"\""+FontName+"\"\n\t").getBytes());
            out.write(("android:textSize="+"\""+((FontSize/3)+2)+"sp"+"\"\n\t").getBytes());
            out.write(("android:layout_marginStart= "+"\""+x+"dp"+"\"\n\t").getBytes());
            out.write(("android:layout_marginTop= "+"\""+y+"dp"+"\"\n\t").getBytes());
            out.write(("android:layout_width= "+"\""+width+"dp"+"\"\n\t").getBytes());
            out.write(("android:layout_height= "+"\""+"wrap_content"+"\"\n\t").getBytes());
            out.write(("android:textcolor= "+"\""+"@color/"+name1+"\"").getBytes());



            out.write(("/>\n").getBytes());
            
            counter++;
          
            
        } catch (IOException ex) {
           
        }
        
        
          Attr type = doc.createAttribute("type");
           type.setValue("text");
           e.setAttributeNode(type);
           
            Attr textfont = doc.createAttribute("font");
           textfont.setValue(FontName);
           e.setAttributeNode(textfont);
           
            Attr textsize = doc.createAttribute("size");
           textsize.setValue((FontSize)+"");
           e.setAttributeNode(textsize);
           
           Attr textcolor = doc.createAttribute("color");
           Color color;
            color = new Color(FontColor.get(0).floatValue(), FontColor.get(1).floatValue(), FontColor.get(1).floatValue());
           String hex = (Integer.toHexString(color.getRGB() & 0xffffff)).toUpperCase();
           hex="0x"+hex;
           textcolor.setValue(hex);
           e.setAttributeNode(textcolor);
           
          
           
           e.appendChild(doc.createTextNode("["+FontText+"]"));
        
    }

    private static void createImageLayer(String name,Element e,int x,int y,int width,int height) throws IOException {
        
                    out.write(("<ImageView "+"android:id= "+"\""+"@+id/"+name+"_"+counter+"\"\n\t").getBytes());
                    out.write(("android:src= "+"\""+"@drawable/"+name+"\"\n\t").getBytes());
                    out.write(("android:layout_marginStart= "+"\""+x+"dp"+"\"\n\t").getBytes());
                    out.write(("android:layout_marginTop= "+"\""+y+"dp"+"\"\n\t").getBytes());
                    out.write(("android:layout_width= "+"\""+width+"dp"+"\"\n\t").getBytes());
                    out.write(("android:layout_height= "+"\""+height+"dp"+"\"\n\t").getBytes());
                    

                    out.write(("/>\n").getBytes());

        
         Attr type = doc.createAttribute("type");
           type.setValue("image");
           e.setAttributeNode(type);
           
           Attr src = doc.createAttribute("src");
           src.setValue( name+ ".png");
           e.setAttributeNode(src);
           
           counter++;
           
        //   System.out.println(srcfolder+ name+ ".png");
    }

    private static void createColorXml(Object k,ArrayList<Double> FontColor) {
        
         String name =((Layer)k).getName();
   
           String name1=name;          
        
          String reg = "[^a-zA-Z0-9]";
          
          if(Character.isDigit(name.charAt(0))){
           name1="_"+name;
           
          }
        
         name1=name1.replaceAll(reg, "_");
         name1+="_color";
             
             Color color1;
            color1 = new Color(FontColor.get(0).floatValue(), FontColor.get(1).floatValue(), FontColor.get(1).floatValue());
           String hex = (Integer.toHexString(color1.getRGB() & 0xffffff)).toUpperCase();
           hex="#"+hex;
           
        try {
            color.write(("<color name="+"\""+name1+"\""+">"+hex+"</color>\n").getBytes());
        } catch (IOException ex) {
            Logger.getLogger(TestPSD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void createStringXml(Object k, String FontText) {
 String name =((Layer)k).getName();
   
           String name1=name;          
        
          String reg = "[^a-zA-Z0-9]";
          
          if(Character.isDigit(name.charAt(0))){
           name1="_"+name;
           
          }
        
         name1=name1.replaceAll(reg, "_");
         name1+="_string";
            
           
      
        try {
            string.write(("<string name="+"\""+name1+"\""+">"+FontText+"</string>\n").getBytes());
        } catch (IOException ex) {
            Logger.getLogger(TestPSD.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    

}
