package psd.parser.layer.additional;

import psd.parser.layer.LayerType;

public interface LayerSectionDividerHandler {
	public void sectionDividerParsed(LayerType type);
}
